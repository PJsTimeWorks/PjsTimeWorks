export default function Home() {
  return (
    <main className="min-h-screen flex items-center justify-center bg-gradient-to-br from-gray-900 to-gray-700 text-white p-4">
      <div className="text-center space-y-6">
        <img
          src="/logo.png"
          alt="Renka Logo"
          className="mx-auto w-48 h-auto"
        />
        <h1 className="text-4xl md:text-6xl font-bold tracking-wide">
          PJS Time Works
        </h1>
        <p className="text-lg md:text-xl text-gray-300">
          Custom Watches That Tell More Than Time.
        </p>
        <a
          href="mailto:patrick.renka@icloud.com"
          className="inline-block mt-4 px-6 py-2 text-lg font-semibold text-white border border-white rounded-full hover:bg-white hover:text-black transition"
        >
          Contact Us
        </a>
      </div>
    </main>
  );
}